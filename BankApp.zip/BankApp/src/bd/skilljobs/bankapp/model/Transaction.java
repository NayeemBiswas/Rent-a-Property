
package bd.skilljobs.bankapp.model;

import java.util.Date;


public class Transaction {
    private Account toAccount = new Account();
    private Account byAccount = new Account();
    private String type;
    private double amount;
    private Date date;

    public Account getToAccount() {
        return toAccount;
    }

    public void setToAccount(Account toAccount) {
        this.toAccount = toAccount;
    }

    public Account getByAccount() {
        return byAccount;
    }

    public void setByAccount(Account byAccount) {
        this.byAccount = byAccount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
    public void deposit(Account account,double amount)
    {
        type ="debit";
        date = new Date();
        this.amount=amount;
        byAccount = account;
        account.setBalance(account.getBalance() + amount);
        account.getTransaction().add(this);
    }
    public void withdraw(Account account,double amount)
    {
        type = "credit";
        date = new Date();
        this.amount=amount;
        byAccount = account;
        account.setBalance(account.getBalance() - amount);
        account.getTransaction().add(this);
    }
    
    public void transfer(Account toAccount,Account byAccount,double amount)
    {
        type = "Transfer";
        date = new Date();
        this.amount= amount;
        this.byAccount = byAccount;
        this.toAccount=toAccount;
        byAccount.withdraw(amount);
        toAccount.deposit(amount);
        
        toAccount.getTransaction().add(this);
        byAccount.getTransaction().add(this);
    }
    
    
}
