
package bd.skilljobs.bankapp.model;

import java.util.ArrayList;

public class Account
{
	private int accNo;
	private String title;
	private double balance;
        private ArrayList<Transaction> transaction = new ArrayList<>();
	
	public Account(int accNo,String title,double balance)
	{
		this.accNo = accNo;
		this.title = title;
		this.balance = balance;
                
                 
	}

public Account() {
        
    }

    public ArrayList<Transaction> getTransaction() {
        return transaction;
    }

    public void setTransaction(ArrayList<Transaction> transaction) {
        this.transaction = transaction;
    }
	
	public int getAccNo()
	{
		return accNo;
	}
	public void setAccNo(int accNo)
	{
		this.accNo=accNo;		
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}
	public double getBalance()
	{
		return balance;
	}
	public void setBalance(double balance)
	{
		this.balance=balance;		
	}
	
	
	
	
	
	
	//deposit & withdraw method
	public void deposit(double ammount)
	{
		balance += ammount;
	}
	public void withdraw(double ammount)
	{
		if(balance>=ammount)
		{
			balance -=ammount;
		}
		else
		{
			System.out.println("Insufficient balance!!!");
		}
	}
        
	@Override
	public String toString()
	{
		return "Account No: "+accNo+"\nTittle"+title+"\nbalance"+balance;
	}
        public void ShowBalance()
        {
            System.out.println("Account No "+accNo+"\nTitle "+title+"\nBalance "+balance+"\n");
            System.out.println(".....................................\n");
            
            for(Transaction t : transaction){
                System.out.println(t.getDate()+","+t.getType()+","+t.getAmount());
            }
        }
}