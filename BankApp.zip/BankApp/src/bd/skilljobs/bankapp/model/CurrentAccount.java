
package bd.skilljobs.bankapp.model;

public class CurrentAccount extends Account{
    private double dailyRate;

    public CurrentAccount(int accNo, String title, double balance) {
        super(accNo, title, balance);
    }
    
    public double getDailyRate() {
        return dailyRate;
    }

    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }

    public CurrentAccount(double dailyRate, int accNo, String title, double balance) {
        super(accNo, title, balance);
        this.dailyRate = dailyRate;
    }

    @Override
    public String toString() {
        return super.toString()+ "dailyRate=" + dailyRate + '\n';
    }
    
    
    
    
}
