
package bd.skilljobs.bankapp;

import bd.skilljobs.bankapp.model.CurrentAccount;
import bd.skilljobs.bankapp.model.Transaction;


public class BankApp {


    public static void main(String[] args) {
        CurrentAccount account = new  CurrentAccount(.01,1001, "Sabbir", 400.00);
        System.out.println(account);
        account.deposit(4000);
        System.out.println(account);
        account.withdraw(3000);
        account.ShowBalance();
        Transaction tr = new Transaction();
        tr.deposit(account,5000.00);
        account.ShowBalance();
        Transaction tr1 = new Transaction();
        tr1.withdraw(account,2000.00);
        account.ShowBalance();
    }
    
}
